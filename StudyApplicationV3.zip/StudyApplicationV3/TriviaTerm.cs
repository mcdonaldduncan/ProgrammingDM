﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyApplication
{
    public class TriviaTerm
    {
        public string term = "";
        public string definition = "";
        public int difficulty = 1;

       
       
        
    }
}
