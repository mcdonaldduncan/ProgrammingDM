﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudyApplication
{
    public class Player
    {
        public string name = "";
        public int score = 0;

    }    
}
